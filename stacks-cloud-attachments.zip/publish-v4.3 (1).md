**Stacks 자동 발행, 진입점**

이 문서는 예약 작업 「Stacks 자동 발행 파이프라인 v4.3」의 로더가 가리키는 진입점이다.

## 실행할 문서

`claude/prompts/publish-runbook.md`를 처음부터 끝까지 읽고 그 지시를 수행한다.

문서를 읽지 못했거나 비어 있으면 발행하지 말고 다음 문구만 보고한다.

발행 규칙 문서를 읽지 못해 이번 회차를 건너뜀

## 실행 스위치

`claude/prompts/publish-flags.md` 첫 줄만 읽는다.

- `DRY_RUN: true`: 후보 수집, 카드 작성, 검증만 수행하고 D1 INSERT와 발행은 하지 않는다.
- `DRY_RUN: false`: runbook의 정상 절차를 수행한다.

`claude/prompts/` 아래 문서는 수정하지 않는다.
